package com.vladancupric.profesori;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProfesoriApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProfesoriApplication.class, args);
	}

}
