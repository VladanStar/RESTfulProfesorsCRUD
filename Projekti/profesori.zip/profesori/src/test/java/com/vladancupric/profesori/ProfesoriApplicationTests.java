package com.vladancupric.profesori;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfesoriApplicationTests {

	@Test
	void contextLoads() {
	}

}
